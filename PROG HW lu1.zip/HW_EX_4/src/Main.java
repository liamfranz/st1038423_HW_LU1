package org.example;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        final int MAX_SCORES = 100;
        int[] scores = new int[MAX_SCORES];
        int count = 0;
        Scanner scanner = new Scanner(System.in);

        // Read scores from the user
        while (count < MAX_SCORES) {
            System.out.print("Enter a score (negative number to end): ");
            int score = scanner.nextInt();

            // Check if the input is negative
            if (score < 0) {
                break;
            }

            // Store the score and increase the count
            scores[count] = score;
            count++;
        }

        // Check if any scores were entered
        if (count == 0) {
            System.out.println("No scores were entered.");
            return;
        }

        // Calculate the average score
        double sum = 0;
        for (int i = 0; i < count; i++) {
            sum += scores[i];
        }
        double average = sum / count;

        // Count scores above or equal to the average and below the average
        int aboveOrEqualCount = 0;
        int belowCount = 0;
        for (int i = 0; i < count; i++) {
            if (scores[i] >= average) {
                aboveOrEqualCount++;
            } else {
                belowCount++;
            }
        }

        // Display the results
        String result = String.format(
                "Average score: %.2f%n" +
                        "Number of scores above or equal to the average: %d%n" +
                        "Number of scores below the average: %d",
                average, aboveOrEqualCount, belowCount
        );

        System.out.println(result);

        // Close the scanner
        scanner.close();
    }
}
