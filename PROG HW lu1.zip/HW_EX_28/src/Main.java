import java.util.Scanner;

public class Main {

    private static final String[] WORDS = {"hangman", "programming", "java", "computer", "keyboard"};

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean playAgain;

        do {
            String word = WORDS[(int) (Math.random() * WORDS.length)];
            StringBuilder currentGuess = new StringBuilder("_".repeat(word.length()));
            int misses = 0;
            int correctGuesses = 0;
            boolean wordGuessed = false;

            while (!wordGuessed) {
                System.out.println("Word: " + currentGuess);
                System.out.println("Misses: " + misses);
                System.out.print("Guess a letter: ");
                char guess = scanner.nextLine().toLowerCase().charAt(0);

                boolean guessCorrect = false;
                for (int i = 0; i < word.length(); i++) {
                    if (word.charAt(i) == guess) {
                        currentGuess.setCharAt(i, guess);
                        guessCorrect = true;
                        correctGuesses++;
                    }
                }

                if (guessCorrect) {
                    System.out.println("Good guess!");
                } else {
                    System.out.println("Wrong guess.");
                    misses++;
                }

                if (correctGuesses == word.length()) {
                    wordGuessed = true;
                    System.out.println("Congratulations! You guessed the word: " + word);
                }

                if (misses >= 6) {
                    System.out.println("Game over! The word was: " + word);
                    wordGuessed = true;
                }
            }

            System.out.print("Do you want to play again? (yes/no): ");
            String response = scanner.nextLine().trim().toLowerCase();
            playAgain = response.equals("yes");

        } while (playAgain);

        System.out.println("Thanks for playing!");
        scanner.close();
    }
}
