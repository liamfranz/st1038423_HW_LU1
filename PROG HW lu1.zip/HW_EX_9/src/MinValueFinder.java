import java.util.Scanner;

public class MinValueFinder {

    // Method to find the smallest element in a double array
    public static double min(double[] array) {
        if (array.length == 0) {
            throw new IllegalArgumentException("Array cannot be empty");
        }
        double minValue = array[0]; // Assume the first element is the smallest
        for (int i = 1; i < array.length; i++) {
            if (array[i] < minValue) {
                minValue = array[i];
            }
        }
        return minValue;
    }

    public static void main(String[] args) {
        // Create an array to store the user input
        double[] numbers = new double[10];
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter ten double values
        for (int i = 0; i < numbers.length; i++) {
            System.out.print("Enter double value #" + (i + 1) + ": ");
            while (true) {
                try {
                    String input = scanner.nextLine();
                    numbers[i] = Double.parseDouble(input);
                    break; // Exit the loop if parsing is successful
                } catch (NumberFormatException e) {
                    System.out.println("Invalid input. Please enter a valid double value.");
                }
            }
        }

        // Find the minimum value using the min method
        double minValue = min(numbers);

        // Display the minimum value
        System.out.println("The smallest value is: " + minValue);

        // Close the scanner
        scanner.close();
    }
}
