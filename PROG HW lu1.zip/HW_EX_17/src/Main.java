import java.util.Arrays;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        // Create a Scanner object for user input
        Scanner scanner = new Scanner(System.in);

        // Prompt user to enter the list of numbers
        System.out.println("Enter the list of numbers (the first number is the count):");
        String input = scanner.nextLine();

        // Split the input string into an array of strings
        String[] inputStrings = input.split("\\s+");

        // Convert the array of strings to an array of integers
        int numElements = Integer.parseInt(inputStrings[0]);
        int[] list = new int[numElements];
        for (int i = 0; i < numElements; i++) {
            list[i] = Integer.parseInt(inputStrings[i + 1]);
        }

        // Check if the list is sorted
        boolean sorted = isSorted(list);

        // Display the result
        String resultMessage = sorted ? "The list is sorted in increasing order." : "The list is not sorted in increasing order.";
        System.out.println(resultMessage);

        // Close the scanner
        scanner.close();
    }

    // Method to check if the array is sorted in increasing order
    public static boolean isSorted(int[] list) {
        for (int i = 1; i < list.length; i++) {
            if (list[i] < list[i - 1]) {
                return false; // The list is not sorted
            }
        }
        return true; // The list is sorted
    }
}
