import java.util.Scanner;

public class EightQueens {

    public static void main(String[] args) {

        int[][] board = new int[8][8];


        if (solve(board, 0)) {

            Scanner scanner = new Scanner(System.in);
            System.out.println("A solution was found. Do you want to display the board? (yes/no)");
            String response = scanner.nextLine();


            if (response.equalsIgnoreCase("yes")) {
                displayBoard(board);
            } else {
                System.out.println("Solution not displayed.");
            }


            scanner.close();
        } else {
            System.out.println("No solution found.");
        }
    }


    public static boolean solve(int[][] board, int row) {

        if (row >= 8) {
            return true;
        }


        for (int col = 0; col < 8; col++) {
            if (isSafe(board, row, col)) {
                // Place the queen
                board[row][col] = 1;


                if (solve(board, row + 1)) {
                    return true;
                }


                board[row][col] = 0;
            }
        }


        return false;
    }


    public static boolean isSafe(int[][] board, int row, int col) {

        for (int i = 0; i < row; i++) {
            if (board[i][col] == 1) {
                return false;
            }
        }


        for (int i = row, j = col; i >= 0 && j >= 0; i--, j--) {
            if (board[i][j] == 1) {
                return false;
            }
        }


        for (int i = row, j = col; i >= 0 && j < 8; i--, j++) {
            if (board[i][j] == 1) {
                return false;
            }
        }

        return true;
    }


    public static void displayBoard(int[][] board) {
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if (board[i][j] == 1) {
                    System.out.print(" Q ");
                } else {
                    System.out.print(" . ");
                }
            }
            System.out.println();
        }
    }
}
