import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        // Create the deck
        ArrayList<Integer> deck = createDeck();

        // Create a Scanner object for user input
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the number of picks to try: ");
        int numberOfPicks = scanner.nextInt();

        // Initialize counter for the number of picks that yield a sum of 24
        int count = 0;

        // Try the specified number of picks to find combinations summing to 24
        for (int i = 0; i < numberOfPicks; i++) {
            // Pick four cards from the deck
            int[] pickedCards = pickFourCards(deck, i); // Using index to pick cards

            // Calculate the sum of picked cards
            int sum = calculateSum(pickedCards);

            // Check if the sum is 24
            if (sum == 24) {
                count++;
                // Uncomment the following line if you want to see the picked cards
                // System.out.println("Picked cards: " + java.util.Arrays.toString(pickedCards));
            }
        }

        // Display the result
        System.out.println("Number of picks that yield a sum of 24: " + count);

        // Close the scanner
        scanner.close();
    }

    // Method to create a deck of cards with values
    public static ArrayList<Integer> createDeck() {
        ArrayList<Integer> deck = new ArrayList<>();

        // Add values for cards 2-10, Jack, Queen, King, Ace
        for (int i = 2; i <= 10; i++) {
            for (int j = 0; j < 4; j++) {
                deck.add(i);
            }
        }
        for (int j = 0; j < 4; j++) {
            deck.add(11); // Jack
        }
        for (int j = 0; j < 4; j++) {
            deck.add(12); // Queen
        }
        for (int j = 0; j < 4; j++) {
            deck.add(13); // King
        }
        for (int j = 0; j < 4; j++) {
            deck.add(1); // Ace
        }

        return deck;
    }

    // Method to pick four sequential cards from the deck
    public static int[] pickFourCards(ArrayList<Integer> deck, int pickIndex) {
        int[] pickedCards = new int[4];
        int startIndex = (pickIndex * 4) % deck.size(); // Cycle through the deck
        for (int i = 0; i < 4; i++) {
            pickedCards[i] = deck.get((startIndex + i) % deck.size());
        }
        return pickedCards;
    }

    // Method to calculate the sum of four cards
    public static int calculateSum(int[] cards) {
        int sum = 0;
        for (int card : cards) {
            sum += card;
        }
        return sum;
    }
}
