import java.util.Arrays;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);


        int[] list1 = readSortedList(scanner, "Enter the first sorted list of integers (the first number is the count):");


        int[] list2 = readSortedList(scanner, "Enter the second sorted list of integers (the first number is the count):");


        int[] mergedList = merge(list1, list2);


        System.out.println("Merged list: " + Arrays.toString(mergedList));


        scanner.close();
    }


    public static int[] readSortedList(Scanner scanner, String prompt) {

        System.out.println(prompt);
        String input = scanner.nextLine();


        String[] inputStrings = input.split("\\s+");


        int numElements = Integer.parseInt(inputStrings[0]);
        int[] list = new int[numElements];


        for (int i = 0; i < numElements; i++) {
            list[i] = Integer.parseInt(inputStrings[i + 1]);
        }

        return list;
    }


    public static int[] merge(int[] list1, int[] list2) {
        int[] mergedList = new int[list1.length + list2.length];
        int i = 0, j = 0, k = 0;


        while (i < list1.length && j < list2.length) {
            if (list1[i] <= list2[j]) {
                mergedList[k++] = list1[i++];
            } else {
                mergedList[k++] = list2[j++];
            }
        }


        while (i < list1.length) {
            mergedList[k++] = list1[i++];
        }


        while (j < list2.length) {
            mergedList[k++] = list2[j++];
        }

        return mergedList;
    }
}
