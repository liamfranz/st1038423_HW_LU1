package org.example;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Array to hold the counts for numbers from 1 to 100
        int[] counts = new int[101]; // index 0 will be unused, using 1-100
        Scanner scanner = new Scanner(System.in);

        while (true) {
            // Prompt the user for an integer
            System.out.print("Enter an integer between 1 and 100 (0 to end): ");
            int number = scanner.nextInt();

            // Break the loop if the input is 0
            if (number == 0) {
                break;
            }

            // Check if the number is within the valid range
            if (number >= 1 && number <= 100) {
                counts[number]++;
            } else {
                System.out.println("Please enter a number between 1 and 100.");
            }
        }

        // Prepare the output string
        StringBuilder output = new StringBuilder("Number counts:\n");
        for (int i = 1; i <= 100; i++) {
            if (counts[i] > 0) {
                String times = (counts[i] > 1) ? " times" : " time";
                output.append(i).append(": ").append(counts[i]).append(times).append("\n");
            }
        }

        // Display the results
        System.out.println(output.toString());

        // Close the scanner
        scanner.close();
    }
}
