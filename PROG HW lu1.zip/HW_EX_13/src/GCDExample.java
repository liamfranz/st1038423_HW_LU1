import java.util.Scanner;

public class GCDExample {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter five numbers
        System.out.println("Enter five numbers:");
        int[] numbers = new int[5];
        for (int i = 0; i < 5; i++) {
            System.out.print("Number " + (i + 1) + ": ");
            numbers[i] = scanner.nextInt();
        }

        // Compute the GCD of the entered numbers
        int resultGCD = gcd(numbers);

        // Display the result
        System.out.println("The GCD of the entered numbers is: " + resultGCD);

        // Close the scanner
        scanner.close();
    }

    // Method to compute the GCD of multiple numbers
    public static int gcd(int... numbers) {
        if (numbers.length == 0) {
            throw new IllegalArgumentException("At least one number must be provided.");
        }

        int gcdResult = numbers[0];
        for (int i = 1; i < numbers.length; i++) {
            gcdResult = gcd(gcdResult, numbers[i]);
        }
        return gcdResult;
    }

    // Helper method to compute the GCD of two numbers
    public static int gcd(int a, int b) {
        while (b != 0) {
            int temp = b;
            b = a % b;
            a = temp;
        }
        return a;
    }
}
