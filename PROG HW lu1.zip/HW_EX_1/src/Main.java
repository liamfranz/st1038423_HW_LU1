package org.example;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Prompt for the number of students
        System.out.print("Enter the total number of students: ");
        int numberOfStudents = scanner.nextInt();

        // Array to hold the scores
        int[] scores = new int[numberOfStudents];

        // Read student scores
        System.out.println("Enter the scores:");
        for (int i = 0; i < numberOfStudents; i++) {
            System.out.printf("Score for student %d: ", (i + 1));
            scores[i] = scanner.nextInt();
        }

        // Find the best score
        int bestScore = findBestScore(scores);

        // Display grades based on the best score
        System.out.println("\nGrades:");
        for (int i = 0; i < numberOfStudents; i++) {
            String grade = determineGrade(scores[i], bestScore);
            System.out.printf("Student %d: Score = %d, Grade = %s%n", (i + 1), scores[i], grade);
        }

        scanner.close();
    }

    // Method to find the best score in the array
    public static int findBestScore(int[] scores) {
        int best = scores[0];
        for (int score : scores) {
            if (score > best) {
                best = score;
            }
        }
        return best;
    }

    // Method to determine the grade based on the score and the best score
    public static String determineGrade(int score, int bestScore) {
        if (score >= bestScore - 10) {
            return "D";
        } else if (score >= bestScore - 20) {
            return "C";
        } else if (score >= bestScore - 30) {
            return "B";
        } else if (score >= bestScore - 40) {
            return "A";
        } else {
            return "F";
        }
    }
}
