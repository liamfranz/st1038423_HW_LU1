import java.util.ArrayList;
import java.util.Scanner;

public class ArrayComparison {

    public static void main(String[] args) {
        // Create a Scanner object for user input
        Scanner scanner = new Scanner(System.in);

        // Read the first list from the user
        int[] list1 = readList(scanner, "Enter the first list of integers (the first number is the count):");

        // Read the second list from the user
        int[] list2 = readList(scanner, "Enter the second list of integers (the first number is the count):");

        // Check if the two lists are strictly identical
        boolean areIdentical = equals(list1, list2);

        // Display the result
        String resultMessage = areIdentical ? "The two lists are strictly identical." : "The two lists are not strictly identical.";
        System.out.println(resultMessage);

        // Close the scanner
        scanner.close();
    }

    // Method to read a list of integers from user input
    public static int[] readList(Scanner scanner, String prompt) {
        // Prompt the user for input
        System.out.println(prompt);
        String input = scanner.nextLine();

        // Split the input string into an array of strings
        String[] inputStrings = input.split("\\s+");

        // Determine the number of elements
        int numElements = Integer.parseInt(inputStrings[0]);
        int[] list = new int[numElements];

        // Fill the list with integers
        for (int i = 0; i < numElements; i++) {
            list[i] = Integer.parseInt(inputStrings[i + 1]);
        }

        return list;
    }

    // Method to check if two integer arrays are strictly identical
    public static boolean equals(int[] list1, int[] list2) {
        // Check if the lengths of both arrays are the same
        if (list1.length != list2.length) {
            return false;
        }

        // Check if all corresponding elements are equal
        for (int i = 0; i < list1.length; i++) {
            if (list1[i] != list2[i]) {
                return false;
            }
        }

        return true;
    }
}
