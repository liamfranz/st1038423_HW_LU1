import java.util.Scanner;

public class ArrayReversal {

    // Method to reverse the array and return the reversed array
    public static double[] reverseArray(double[] array) {
        double[] reversedArray = new double[array.length];
        for (int i = 0; i < array.length; i++) {
            reversedArray[i] = array[array.length - 1 - i];
        }
        return reversedArray;
    }

    public static void main(String[] args) {
        // Create an array to store the user input
        double[] numbers = new double[10];
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter ten double values
        for (int i = 0; i < numbers.length; i++) {
            System.out.print("Enter double value #" + (i + 1) + ": ");
            while (true) {
                try {
                    String input = scanner.nextLine();
                    numbers[i] = Double.parseDouble(input);
                    break; // Exit the loop if parsing is successful
                } catch (NumberFormatException e) {
                    System.out.println("Invalid input. Please enter a valid double value.");
                }
            }
        }

        // Reverse the array using the reverseArray method
        double[] reversedNumbers = reverseArray(numbers);

        // Build the result string to display the reversed numbers
        StringBuilder result = new StringBuilder("Reversed numbers:\n");
        for (double num : reversedNumbers) {
            result.append(num).append("\n");
        }

        // Display the reversed numbers
        System.out.println(result.toString());

        // Close the scanner
        scanner.close();
    }
}
