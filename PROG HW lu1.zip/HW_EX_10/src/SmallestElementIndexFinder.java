import java.util.Scanner;

public class SmallestElementIndexFinder {

    // Method to find the index of the smallest element in a double array
    public static int indexOfSmallestElement(double[] array) {
        if (array.length == 0) {
            throw new IllegalArgumentException("Array cannot be empty");
        }

        int indexOfSmallest = 0; // Assume the first element is the smallest
        for (int i = 1; i < array.length; i++) {
            if (array[i] < array[indexOfSmallest]) {
                indexOfSmallest = i;
            }
        }
        return indexOfSmallest;
    }

    public static void main(String[] args) {
        // Create an array to store the user input
        double[] numbers = new double[10];
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter ten double values
        for (int i = 0; i < numbers.length; i++) {
            System.out.print("Enter double value #" + (i + 1) + ": ");
            while (true) {
                try {
                    String input = scanner.nextLine();
                    numbers[i] = Double.parseDouble(input);
                    break; // Exit the loop if parsing is successful
                } catch (NumberFormatException e) {
                    System.out.println("Invalid input. Please enter a valid double value.");
                }
            }
        }

        // Find the index of the smallest value using the indexOfSmallestElement method
        int index = indexOfSmallestElement(numbers);

        // Display the index
        System.out.println("The index of the smallest value is: " + index);

        // Close the scanner
        scanner.close();
    }
}
