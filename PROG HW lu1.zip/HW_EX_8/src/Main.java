import java.util.Scanner;

public class Main {

    // Overloaded method to calculate the average of an int array
    public static int average(int[] array) {
        if (array.length == 0) return 0; // Handle edge case of empty array
        int sum = 0;
        for (int num : array) {
            sum += num;
        }
        return sum / array.length;
    }

    // Overloaded method to calculate the average of a double array
    public static double average(double[] array) {
        if (array.length == 0) return 0.0; // Handle edge case of empty array
        double sum = 0.0;
        for (double num : array) {
            sum += num;
        }
        return sum / array.length;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        // Prompt the user to enter ten double values
        double[] numbers = new double[10];
        for (int i = 0; i < numbers.length; i++) {
            System.out.print("Enter double value #" + (i + 1) + ": ");
            try {
                numbers[i] = Double.parseDouble(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid double value.");
                i--; // Decrement the counter to re-enter the value
            }
        }

        // Calculate the average using the overloaded method
        double avg = average(numbers);

        // Display the result
        System.out.println("The average value is: " + avg);

        // Close the scanner
        scanner.close();
    }
}
