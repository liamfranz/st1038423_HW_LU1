public class LockerProblem {

    public static void main(String[] args) {

        boolean[] lockers = new boolean[100];


        for (int student = 1; student <= 100; student++) {

            for (int locker = student - 1; locker < 100; locker += student) {
                lockers[locker] = !lockers[locker];
            }
        }


        StringBuilder result = new StringBuilder();
        for (int i = 0; i < lockers.length; i++) {
            if (lockers[i]) {
                result.append(i + 1).append(" "); // Add 1 because locker numbers start from 1
            }
        }


        System.out.println(result.toString().trim());
    }
}
