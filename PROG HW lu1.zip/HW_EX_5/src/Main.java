package org.example;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        final int NUMBER_OF_INPUTS = 10;
        int[] numbers = new int[NUMBER_OF_INPUTS];
        int distinctCount = 0;
        Scanner scanner = new Scanner(System.in);

        // Read ten numbers from the user
        for (int i = 0; i < NUMBER_OF_INPUTS; i++) {
            System.out.print("Enter number " + (i + 1) + ": ");
            int number = scanner.nextInt();

            // Check if the number is already in the array
            boolean isDistinct = true;
            for (int j = 0; j < distinctCount; j++) {
                if (numbers[j] == number) {
                    isDistinct = false;
                    break;
                }
            }

            // Store the number if it is distinct
            if (isDistinct) {
                numbers[distinctCount] = number;
                distinctCount++;
            }
        }

        // Prepare the output string
        StringBuilder result = new StringBuilder("Number of distinct numbers: " + distinctCount + "\nDistinct numbers:\n");
        for (int i = 0; i < distinctCount; i++) {
            result.append(numbers[i]).append(" ");
        }

        // Display the results
        System.out.println(result.toString().trim());

        // Close the scanner
        scanner.close();
    }
}
