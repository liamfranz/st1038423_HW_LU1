import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        // Array to store the numbers
        double[] numbers = new double[10];
        Scanner scanner = new Scanner(System.in);

        // Prompt user to enter ten double numbers
        for (int i = 0; i < 10; i++) {
            System.out.print("Enter number " + (i + 1) + ": ");
            numbers[i] = scanner.nextDouble();
        }

        // Sort the array using Bubble Sort
        bubbleSort(numbers);

        // Display the sorted numbers
        System.out.println("Sorted numbers:");
        for (double num : numbers) {
            System.out.println(num);
        }

        // Close the scanner
        scanner.close();
    }

    // Bubble Sort method
    public static void bubbleSort(double[] array) {
        int n = array.length;
        boolean swapped;
        for (int i = 0; i < n - 1; i++) {
            swapped = false;
            for (int j = 0; j < n - 1 - i; j++) {
                if (array[j] > array[j + 1]) {
                    // Swap the elements
                    double temp = array[j];
                    array[j] = array[j + 1];
                    array[j + 1] = temp;
                    swapped = true;
                }
            }
            // If no elements were swapped, the array is sorted
            if (!swapped) {
                break;
            }
        }
    }
}
