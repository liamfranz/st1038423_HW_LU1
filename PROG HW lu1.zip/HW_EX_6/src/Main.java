import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        // Create an array to store counts for numbers 0 to 9
        int[] counts = new int[10];
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter 100 numbers between 0 and 9
        System.out.println("Please enter 100 integers between 0 and 9:");

        for (int i = 0; i < 100; i++) {
            int number = scanner.nextInt();

            // Check if the number is within the valid range
            if (number >= 0 && number < 10) {
                counts[number]++; // Increment the count for the entered number
            } else {
                System.out.println("Invalid input. Please enter a number between 0 and 9.");
                i--; // Decrement i to repeat this iteration
            }
        }

        // Build the result string to display
        StringBuilder result = new StringBuilder("Number counts:\n");
        for (int i = 0; i < counts.length; i++) {
            result.append(i).append(": ").append(counts[i]).append("\n");
        }

        // Display the result using System.out
        System.out.println(result.toString());

        // Close the scanner
        scanner.close();
    }
}
