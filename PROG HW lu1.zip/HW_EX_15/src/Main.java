import java.util.Scanner;

class Student {
    String name;
    int score;

    // Constructor
    public Student(String name, int score) {
        this.name = name;
        this.score = score;
    }
}

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Prompt user for the number of students
        System.out.print("Enter the number of students: ");
        int numStudents = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character

        // Create arrays to hold student names and scores
        String[] names = new String[numStudents];
        int[] scores = new int[numStudents];

        // Prompt user for student names and scores
        for (int i = 0; i < numStudents; i++) {
            System.out.print("Enter the name of student " + (i + 1) + ": ");
            names[i] = scanner.nextLine();
            System.out.print("Enter the score for " + names[i] + ": ");
            scores[i] = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character
        }

        // Combine names and scores into an array of Student objects
        Student[] students = new Student[numStudents];
        for (int i = 0; i < numStudents; i++) {
            students[i] = new Student(names[i], scores[i]);
        }

        // Display the students and their scores
        System.out.println("Students and their scores:");
        for (Student student : students) {
            System.out.println("Name: " + student.name + ", Score: " + student.score);
        }

        // Close the scanner
        scanner.close();
    }
}
