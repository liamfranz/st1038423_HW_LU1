import java.util.Arrays;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);


        System.out.print("Enter a string to be sorted: ");
        String input = scanner.nextLine();


        String sortedString = sort(input);


        System.out.println("Sorted string: " + sortedString);


        scanner.close();
    }


    public static String sort(String s) {

        char[] characters = s.toCharArray();


        Arrays.sort(characters);


        return new String(characters);
    }
}
