import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);


        int[] numbers = readNumbers(scanner);


        displayCombinations(numbers);


        scanner.close();
    }


    public static int[] readNumbers(Scanner scanner) {
        int[] numbers = new int[10];
        System.out.println("Enter 10 integers separated by spaces:");


        String input = scanner.nextLine();
        String[] inputStrings = input.split("\\s+");


        if (inputStrings.length != 10) {
            System.out.println("You must enter exactly 10 integers.");
            System.exit(1); // Exit the program if input is invalid
        }


        for (int i = 0; i < 10; i++) {
            numbers[i] = Integer.parseInt(inputStrings[i]);
        }

        return numbers;
    }


    public static void displayCombinations(int[] numbers) {
        StringBuilder result = new StringBuilder();


        for (int i = 0; i < numbers.length; i++) {
            for (int j = i + 1; j < numbers.length; j++) {
                result.append("(").append(numbers[i]).append(", ").append(numbers[j]).append(")\n");
            }
        }


        System.out.println("Combinations of picking two numbers:\n" + result.toString());
    }
}
