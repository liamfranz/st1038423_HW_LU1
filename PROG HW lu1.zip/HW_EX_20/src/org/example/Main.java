package org.example;

import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {

        String[] suits = {"Hearts", "Diamonds", "Clubs", "Spades"};
        String[] ranks = {"2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"};


        ArrayList<String> deck = new ArrayList<>();
        for (String suit : suits) {
            for (String rank : ranks) {
                deck.add(rank + " of " + suit);
            }
        }

        ArrayList<String> pickedCards = new ArrayList<>();
        int numberOfPicks = 0;


        while (pickedCards.size() < suits.length) {

            int randomIndex = (int) (Math.random() * deck.size());
            String card = deck.get(randomIndex);


            if (!pickedCards.contains(card)) {
                pickedCards.add(card);
                numberOfPicks++;
            }
        }


        System.out.println("Picked cards: " + pickedCards);
        System.out.println("Total picks: " + numberOfPicks);
    }
}
