import java.util.Scanner;

public class EliminateDuplicatesExample {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Read ten integers from the user
        int[] numbers = new int[10];
        System.out.println("Enter ten integers:");
        for (int i = 0; i < 10; i++) {
            System.out.print("Number " + (i + 1) + ": ");
            numbers[i] = scanner.nextInt();
        }

        // Remove duplicates
        int[] uniqueNumbers = eliminateDuplicates(numbers);

        // Display the result
        System.out.println("Array after eliminating duplicates:");
        for (int num : uniqueNumbers) {
            System.out.print(num + " ");
        }
        System.out.println();

        // Close the scanner
        scanner.close();
    }

    // Method to eliminate duplicate values in the array
    public static int[] eliminateDuplicates(int[] list) {
        int[] tempArray = new int[list.length]; // Temporary array to store unique values
        int uniqueCount = 0;

        for (int number : list) {
            // Check if the number is already in the tempArray
            boolean isDuplicate = false;
            for (int j = 0; j < uniqueCount; j++) {
                if (tempArray[j] == number) {
                    isDuplicate = true;
                    break;
                }
            }
            // If it's not a duplicate, add it to the tempArray
            if (!isDuplicate) {
                tempArray[uniqueCount] = number;
                uniqueCount++;
            }
        }

        // Create the final unique array of the correct size
        int[] uniqueArray = new int[uniqueCount];
        for (int i = 0; i < uniqueCount; i++) {
            uniqueArray[i] = tempArray[i];
        }

        return uniqueArray;
    }
}
