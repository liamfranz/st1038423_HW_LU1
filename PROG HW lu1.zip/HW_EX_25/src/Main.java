import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Prompt the user for the number of values
        System.out.print("Enter the number of values in the series: ");
        int size = scanner.nextInt();

        // Create an array to hold the values
        int[] values = new int[size];

        // Prompt the user to enter the values
        System.out.println("Enter " + size + " integers:");
        for (int i = 0; i < size; i++) {
            values[i] = scanner.nextInt();
        }

        // Check if the array has four consecutive numbers with the same value
        boolean hasConsecutiveFour = isConsecutiveFour(values);

        // Display the result
        if (hasConsecutiveFour) {
            System.out.println("The series contains four consecutive numbers with the same value.");
        } else {
            System.out.println("The series does not contain four consecutive numbers with the same value.");
        }

        // Close the scanner
        scanner.close();
    }

    // Method to check for four consecutive numbers with the same value
    public static boolean isConsecutiveFour(int[] values) {
        // Check for consecutive numbers in the array
        for (int i = 0; i < values.length - 3; i++) {
            if (values[i] == values[i + 1] && values[i] == values[i + 2] && values[i] == values[i + 3]) {
                return true; // Found four consecutive numbers
            }
        }
        return false; // No four consecutive numbers found
    }
}
