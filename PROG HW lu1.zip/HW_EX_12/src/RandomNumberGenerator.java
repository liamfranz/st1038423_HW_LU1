import java.util.Scanner;

public class RandomNumberGenerator {

    // Method to get a random number between 1 and 54, excluding specified numbers
    public static int getRandom(int[] excludedNumbers) {
        int randomNumber;
        boolean isExcluded;

        // Loop until a valid number is found
        do {
            randomNumber = 1 + (int)(Math.random() * 54); // Generate a number between 1 and 54
            isExcluded = false;

            // Check if the generated number is in the excluded list
            for (int num : excludedNumbers) {
                if (num == randomNumber) {
                    isExcluded = true;
                    break; // Exit the loop if the number is found in the excluded list
                }
            }
        } while (isExcluded); // Repeat if the number is excluded

        return randomNumber;
    }

    public static void main(String[] args) {
        // Create a scanner for user input
        Scanner scanner = new Scanner(System.in);

        // Prompt user to enter excluded numbers
        System.out.print("Enter numbers to exclude, separated by commas (e.g., 2,5,9): ");
        String input = scanner.nextLine();

        // Convert the input string to an array of integers
        String[] inputArray = input.split(",");
        int[] excludedNumbers = new int[inputArray.length];

        try {
            for (int i = 0; i < inputArray.length; i++) {
                excludedNumbers[i] = Integer.parseInt(inputArray[i].trim());
            }
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Please enter valid integers separated by commas.");
            scanner.close(); // Close the scanner
            System.exit(0); // Exit the program on invalid input
        }

        // Generate a random number that is not in the excluded list
        int randomNumber = getRandom(excludedNumbers);

        // Display the result
        System.out.println("Generated random number (excluding specified numbers): " + randomNumber);

        // Close the scanner
        scanner.close();
    }
}
